package stackTest;

import stackArray.Stack; //change to switch between array and LL version

/**
 * class to hold method that demos stack operations.
 * @author George Kriger
 *
 */
public class stackTest {

	/**
	 * simple main() to demo stack operations
	 * @param args command line arguments - ignored
	 */
	public static void main(String[] args) {
		Stack<Integer> myStack = new Stack<>();
		
		for(int i=0; i<10; i++)
			myStack.push(i);	//uses autoboxing
		
		while(!myStack.empty()) {
			System.out.println(myStack.pop());
		}
		
	}//main

}//class
