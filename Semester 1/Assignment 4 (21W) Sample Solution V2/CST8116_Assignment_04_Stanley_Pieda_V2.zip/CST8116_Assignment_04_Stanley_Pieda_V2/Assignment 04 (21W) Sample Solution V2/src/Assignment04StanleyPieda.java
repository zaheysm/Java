/*
 * Student Name: Stanley Pieda
 * Lab Professor: Stanley Pieda
 * Due Date: The due date
 * Description: Assignment 04 Sample Solution
 */

/* Assignment 04 class used to practice Git */
public class Assignment04StanleyPieda {

	/* Method main is used to print some even numbers */
	public static void main(String[] args) {
		int[] values = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
		System.out.print("Even numbers are: ");
		for(int index = 0; index < values.length; index++) {
			    if(values[index] % 2 == 0){         
			        System.out.print(values[index] + " ");
			    }
		}
		System.out.println(); // newline after loop
		System.out.println("Program by Stanley Pieda");

	}

}
